<div class="container">
    <div class="row content">
        <div class="col-6">
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam aut beatae commodi consectetur eius
                facere in iusto nam natus, nisi omnis possimus sint voluptatem? Cumque delectus ducimus optio sint
                velit.
            </p>
        </div>
        <div class="col-6">
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam aut beatae commodi consectetur eius
                facere in iusto nam natus, nisi omnis possimus sint voluptatem? Cumque delectus ducimus optio sint
                velit.
            </p>
        </div>
    </div>
</div>

