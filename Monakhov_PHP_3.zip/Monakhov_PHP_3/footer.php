<div class="bg-light">
    <div class="container-fluid">
        <div class="footer">
            Все права защищены.
        </div>
    </div>
</div>