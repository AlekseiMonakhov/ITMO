<div class="container">
    <div class="row banner">
        <div class="card " style="width: 18rem;">
            <div class="card-body">
                <h5 class="card-title">Это рекламный баннер</h5>
                <p class="card-text">Импровизированный рекламный баннер. Если он не подгрузится на старнице, ничего страшного не
                    произойдет, поэтому его можно подключить через include_once()</p>
                <a href="#" class="btn btn-primary">Посмотреть рекламу</a>
            </div>
        </div>
    </div>
</div>