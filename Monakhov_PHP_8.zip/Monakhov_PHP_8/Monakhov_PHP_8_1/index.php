<?php
class Student {
    private $name = "Имя";
    private $age = "Возраст";
    private $group = "Группа";

    public function setName($name) {
        $this->name = $name;
        return $this->name;
    }
    public function getName() {
        return $this->name;
    }

    public function setAge($age) {
        $this->age = $age;
        return $this->age;
    }
    public function getAge() {
        return $this->age;
    }

    public function setGroup($group) {
        $this->group = $group;
        return $this->group;
    }
    public function getGroup() {
        return $this->group;
    }
}

$Ivan = new Student;
$Ivan->setName("Иван");
$Ivan->setAge(21);
$Ivan->setGroup("U1001");

$Vasya = new Student;
$Vasya->setName("Вася");
$Vasya->setAge(20);
$Vasya->setGroup("U1002");

$sum = ($Ivan->getAge() + $Vasya->getAge());
echo $sum;

?>