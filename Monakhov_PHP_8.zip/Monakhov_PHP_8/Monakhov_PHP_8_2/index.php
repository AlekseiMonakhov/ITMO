<?php

class User {
    protected $name = "Имя";
    protected $age = "Возраст";

    public function setName($name) {
        $this->name = $name;
        return $this->name;
    }

    public function getName() {
        return $this->name;
    }

    public function setAge($age) {
        $this->age = $age;
        return $this->age;
    }

    public function getAge() {
        return $this->age;
    }
}

class Worker extends User {
    private $salary;

    public function setSalary($salary) {
        $this->salary = $salary;
        return $this->salary;
    }

    public function getSalary() {
        return $this->salary;
    }
}

$Ivan = new Worker;
$Ivan->setName("Иван");
$Ivan->setAge(25);
$Ivan->setSalary(1000);

$Vasya = new Worker;
$Vasya->setName("Вася");
$Vasya->setAge(26);
$Vasya->setSalary(2000);

$sum = ($Ivan->getSalary() + $Vasya->getSalary());
echo $sum;
?>