<form action="conclusion.php" method="get">
    <p><b>Вопрос 1. Кто является президентом России? </b></p>
    <p><input type="radio" name="lastname" value="Буш">Буш<Br>
        <input type="radio" name="lastname" value="Путин">Путин<Br>
        <input type="radio" name="lastname" value="Медведев">Медведев</p>

    <p><b>Вопрос 2. Сколько дней в високосном году?</b></p>
    <p><input type="radio" name="year" value="365">365<Br>
        <input type="radio" name="year" value="366">366<Br>
        <input type="radio" name="year" value="368">368</p>
    <p><input type="submit"></p>
</form>
