<?php
function foo(){
    function bar(){
        echo 'Hello world';
 }
}
foo();
bar();