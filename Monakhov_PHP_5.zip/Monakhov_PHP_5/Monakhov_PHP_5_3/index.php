<?php

function foo($a) {
    $a = "Hello World!";
    echo $a;
}

foo("Привет!");


