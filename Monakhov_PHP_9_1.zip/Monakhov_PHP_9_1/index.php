<?php
$mysqli = mysqli_connect("localhost", "root", "root", "newdatabase");

if($mysqli === false){
    die("ERROR: Could not connect. ". mysqli_connect_error());
}

$res = $mysqli->query('SELECT * FROM zakaz;');

echo "<table border=1>";
echo"
    <tr>
         <td>id</td>    
         <td>Имя заказчика</td>
         <td>Фамилия заказчика</td>
         <td>E-mail заказчика</td>
         <td>Название товара</td>
         <td>Количество штук</td>
    </tr>";
    for ($row_no = 0; $row_no <= $res->num_rows - 1; $row_no++){
        $res->data_seek($row_no);
        $row = $res->fetch_assoc();
        echo "
    <tr>
        <td>".$row['id']."</td>
        <td>".$row['Name']."</td>
        <td>".$row['Fam']."</td>
        <td>".$row['Email']."</td>
        <td>".$row['Tovar']."</td>
        <td>".$row['Col']."</td>
    <tr>";
}
echo "</table>";
echo "<br>";
?>