<?php
session_start();
// Разрегистрировали переменную
unset($_SESSION['username']);
unset($_SESSION['new']);
// Разрушаем сессию
session_destroy();
