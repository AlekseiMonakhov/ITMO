<?php


if ($a==1 || $a==2)
{
	echo "Hello world";
} elseif ($a==3) {
	echo "Hi world";
} else {
	echo "Goodbye world";
}

?>